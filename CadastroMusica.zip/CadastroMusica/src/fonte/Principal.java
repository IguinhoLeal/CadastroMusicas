/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fonte;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

/**
 *
 * @author Igor
 */
public class Principal {
    public static void main(String[] args) {
		String nome,nomealbum,nomeartista,tipogenero;
		double duracao;
		int nota,ano,fkgenero,fkalbum,fkartista;
		int opc,opc2,opc3,opc4,opc5,opc6;
		
		Scanner x = new Scanner(System.in);
		
		do{
		System.out.println("1.INSERIR MUSICA\n2.PESQUISAR\n3.RELATORIO\n4.SAIR\nOPCAO:");
		opc = Integer.parseInt(x.nextLine());
		
		switch(opc){
			case 1:
				System.out.println("1.NOVO ALBUM\n2.ALBUM EXISTENTE\n3.SAIR\nOPCAO:");
				opc2 = Integer.parseInt(x.nextLine());
				switch(opc2){
				case 1:
					System.out.println("1.NOVO ARTISTA\n2.ARTISTA EXISTENTE\n3.SAIR\nOPCAO:");
					opc3 = Integer.parseInt(x.nextLine());
					
					switch(opc3){
						case 1:
								System.out.println("1.NOVO GENERO\n2.GENERO EXISTENTE\n3.SAIR\nOPCAO:");
								opc4 = Integer.parseInt(x.nextLine());
								switch(opc4){
								case 1:
								System.out.println("TIPO GENERO:");
								tipogenero = x.nextLine();
								Genero G = new Genero(tipogenero);
								if(Conexao.inserirGenero(G)!=0) {
									System.out.println("Genero inserido com sucesso no banco!");
								} else {
									System.out.println("Erro na inserção!");
								}
								
								ResultSet res = (ResultSet) Conexao.relatorioGenero();
								if(res!=null) {
									try {
										while(res.next()) {
											System.out.println("ID: "+res.getInt("id"));
											System.out.println("Tipo: "+res.getString("tipo"));
											System.out.println("==========");
										}
									} catch (SQLException e) {
										System.out.println("Problema para exibir registros!");
									}
								} else {
									System.out.println("A pesquisa não retornou nenhum registro!");
								}
								
								System.out.println("NOME DO ARTISTA:");
								nomeartista = x.nextLine();
								Artista Ar = new Artista(nomeartista);
								
								System.out.println("ID GENERO:");
								fkgenero = Integer.parseInt(x.nextLine());
								if(Conexao.inserirArtista(Ar,fkgenero)!=0) {
									System.out.println("Artista inserido com sucesso no banco!");
								} else {
									System.out.println("Erro na inserção!");
								}
								
								ResultSet res2 = (ResultSet) Conexao.relatorioArtista();
								if(res2!=null) {
									try {
										while(res2.next()) {
											System.out.println("ID: "+res2.getInt("id"));
											System.out.println("Nome: "+res2.getString("nome"));
											System.out.println("==========");
										}
									} catch (SQLException e) {
										System.out.println("Problema para exibir registros!");
									}
								} else {
									System.out.println("A pesquisa não retornou nenhum registro!");
								}
								
								System.out.println("NOME DA ALBUM:");
								nomealbum = x.nextLine();
								System.out.println("ANO DO ALBUM:");
								ano = Integer.parseInt(x.nextLine());
								System.out.println("ID ARTISTA:");
								fkartista = Integer.parseInt(x.nextLine());
								
								Album A = new Album(nomealbum, ano);
								if(Conexao.inserirAlbum(A,fkartista)!=0) {
									System.out.println("Album inserido com sucesso no banco!");
								} else {
									System.out.println("Erro na inserção!");
								}
								
								ResultSet res3 = (ResultSet) Conexao.relatorioAlbum();
								if(res3!=null) {
									try {
										while(res3.next()) {
											System.out.println("ID: "+res3.getInt("id"));
											System.out.println("Nome: "+res3.getString("nome"));
											System.out.println("==========");
										}
									} catch (SQLException e) {
										System.out.println("Problema para exibir registros!");
									}
								} else {
									System.out.println("A pesquisa não retornou nenhum registro!");
								}
								
								System.out.println("NOME:");
								nome = x.nextLine();
								System.out.println("DURACAO:");
								duracao = Double.parseDouble(x.nextLine());
								System.out.println("NOTA:");
								nota = Integer.parseInt(x.nextLine());
								System.out.println("ID ALBUM:");
								fkalbum = Integer.parseInt(x.nextLine());
								
								Musica M = new Musica(nome, duracao, nota);
								if(Conexao.inserirMusica(M,fkalbum)!=0) {
									System.out.println("Musica inserida com sucesso no banco!");
								} else {
									System.out.println("Erro na inserção!");
								}
							break;
							case 2:
								ResultSet res6 = (ResultSet) Conexao.relatorioGenero();
								if(res6!=null) {
									try {
										while(res6.next()) {
											System.out.println("ID: "+res6.getInt("id"));
											System.out.println("Tipo: "+res6.getString("tipo"));
											System.out.println("==========");
										}
									} catch (SQLException e) {
										System.out.println("Problema para exibir registros!");
									}
								} else {
									System.out.println("A pesquisa não retornou nenhum registro!");
								}
								
								System.out.println("NOME DO ARTISTA:");
								nomeartista = x.nextLine();
								Artista Art = new Artista(nomeartista);
								
								System.out.println("ID GENERO:");
								fkgenero = Integer.parseInt(x.nextLine());
								if(Conexao.inserirArtista(Art,fkgenero)!=0) {
									System.out.println("Artista inserido com sucesso no banco!");
								} else {
									System.out.println("Erro na inserção!");
								}
								
								ResultSet res7 = (ResultSet) Conexao.relatorioArtista();
								if(res7!=null) {
									try {
										while(res7.next()) {
											System.out.println("ID: "+res7.getInt("id"));
											System.out.println("Nome: "+res7.getString("nome"));
											System.out.println("==========");
										}
									} catch (SQLException e) {
										System.out.println("Problema para exibir registros!");
									}
								} else {
									System.out.println("A pesquisa não retornou nenhum registro!");
								}
								
								System.out.println("NOME DA ALBUM:");
								nomealbum = x.nextLine();
								System.out.println("ANO DO ALBUM:");
								ano = Integer.parseInt(x.nextLine());
								System.out.println("ID ARTISTA:");
								fkartista = Integer.parseInt(x.nextLine());
								
								Album a = new Album(nomealbum, ano);
								if(Conexao.inserirAlbum(a,fkartista)!=0) {
									System.out.println("Album inserido com sucesso no banco!");
								} else {
									System.out.println("Erro na inserção!");
								}
								
								ResultSet res8 = (ResultSet) Conexao.relatorioAlbum();
								if(res8!=null) {
									try {
										while(res8.next()) {
											System.out.println("ID: "+res8.getInt("id"));
											System.out.println("Nome: "+res8.getString("nome"));
											System.out.println("==========");
										}
									} catch (SQLException e) {
										System.out.println("Problema para exibir registros!");
									}
								} else {
									System.out.println("A pesquisa não retornou nenhum registro!");
								}
								
								System.out.println("NOME:");
								nome = x.nextLine();
								System.out.println("DURACAO:");
								duracao = Double.parseDouble(x.nextLine());
								System.out.println("NOTA:");
								nota = Integer.parseInt(x.nextLine());
								System.out.println("ID ALBUM:");
								fkalbum = Integer.parseInt(x.nextLine());
								
								Musica m = new Musica(nome, duracao, nota);
								if(Conexao.inserirMusica(m,fkalbum)!=0) {
									System.out.println("Musica inserida com sucesso no banco!");
								} else {
									System.out.println("Erro na inserção!");
								}
							break;
							case 3:
								System.out.println("SAINDO!!!");
							break;
							default:
								System.out.println("OPCAO INVALIDA!!!");
							}
					break;
					case 2:
						//AQII SE CASO FIZER NOVO ALBUM DE ARTISTA EXISTENTE//
						ResultSet res4 = (ResultSet) Conexao.relatorioArtista();
						if(res4!=null) {
							try {
								while(res4.next()) {
									System.out.println("ID: "+res4.getInt("id"));
									System.out.println("Nome: "+res4.getString("nome"));
									System.out.println("==========");
								}
							} catch (SQLException e) {
								System.out.println("Problema para exibir registros!");
							}
						} else {
							System.out.println("A pesquisa não retornou nenhum registro!");
						}
						
						System.out.println("NOME DA ALBUM:");
						nomealbum = x.nextLine();
						System.out.println("ANO DO ALBUM:");
						ano = Integer.parseInt(x.nextLine());
						System.out.println("ID ARTISTA:");
						fkartista = Integer.parseInt(x.nextLine());
						
						Album Al = new Album(nomealbum, ano);
						if(Conexao.inserirAlbum(Al,fkartista)!=0) {
							System.out.println("Album inserido com sucesso no banco!");
						} else {
							System.out.println("Erro na inserção!");
						}
						
						ResultSet res5 = (ResultSet) Conexao.relatorioAlbum();
						if(res5!=null) {
							try {
								while(res5.next()) {
									System.out.println("ID: "+res5.getInt("id"));
									System.out.println("Nome: "+res5.getString("nome"));
									System.out.println("==========");
								}
							} catch (SQLException e) {
								System.out.println("Problema para exibir registros!");
							}
						} else {
							System.out.println("A pesquisa não retornou nenhum registro!");
						}
						
						System.out.println("NOME:");
						nome = x.nextLine();
						System.out.println("DURACAO:");
						duracao = Double.parseDouble(x.nextLine());
						System.out.println("NOTA:");
						nota = Integer.parseInt(x.nextLine());
						System.out.println("ID ALBUM:");
						fkalbum = Integer.parseInt(x.nextLine());
						
						Musica Mu = new Musica(nome, duracao, nota);
						if(Conexao.inserirMusica(Mu,fkalbum)!=0) {
							System.out.println("Musica inserida com sucesso no banco!");
						} else {
							System.out.println("Erro na inserção!");
						}
					break;
					case 3:
						System.out.println("SAINDO!!!");
					break;
					default:
						System.out.println("OPCAO INVALIDA!!!");
					}
				break;
				case 2:
					ResultSet res3 = (ResultSet) Conexao.relatorioAlbum();
					if(res3!=null) {
						try {
							while(res3.next()) {
								System.out.println("ID: "+res3.getInt("id"));
								System.out.println("Nome: "+res3.getString("nome"));
								System.out.println("==========");
							}
						} catch (SQLException e) {
							System.out.println("Problema para exibir registros!");
						}
					} else {
						System.out.println("A pesquisa não retornou nenhum registro!");
					}
					
					System.out.println("NOME:");
					nome = x.nextLine();
					System.out.println("DURACAO:");
					duracao = Double.parseDouble(x.nextLine());
					System.out.println("NOTA:");
					nota = Integer.parseInt(x.nextLine());
					System.out.println("ID ALBUM:");
					fkalbum = Integer.parseInt(x.nextLine());
					
					Musica M = new Musica(nome, duracao, nota);
					if(Conexao.inserirMusica(M,fkalbum)!=0) {
						System.out.println("Musica inserida com sucesso no banco!");
					} else {
						System.out.println("Erro na inserção!");
					}
				break;
				case 3:
					System.out.println("SAINDO!!!");
				break;
				default:
					System.out.println("OPCAO INVALIDA!!!");
				}	
			break;
			case 2:
				System.out.println("1.NOME DA MUSICA\n2.NOME DO ARTISTA\n3.NOME DO ALBUM\n4.SAIR\nOPAO:");
				opc5 = Integer.parseInt(x.nextLine());
				
				switch(opc5){
					case 1:
						System.out.println("NOME DA MUSICA:");
						nome = x.nextLine();
						
						ResultSet res3 = (ResultSet) Conexao.pesqMusica(nome);
						if(res3!=null) {
							try {
								while(res3.next()) {
									System.out.println("Nome: "+res3.getString("nome"));
									System.out.println("Duração: "+res3.getDouble("duracao"));
									System.out.println("Nota: "+res3.getInt("nota"));
									System.out.println("==========");
								}
							} catch (SQLException e) {
								System.out.println("Problema para exibir registros!");
							}
						} else {
							System.out.println("A pesquisa não retornou nenhum registro!");
						}
					break;	
					case 2:
						System.out.println("NOME DO ARTISTA:");
						nome = x.nextLine();
						
						ResultSet res = (ResultSet) Conexao.pesqArtista(nome);
						if(res!=null) {
							try {
								while(res.next()) {
									System.out.println("ID: "+res.getInt("id"));
									System.out.println("Nome: "+res.getString("nome"));
									System.out.println("==========");
								}
							} catch (SQLException e) {
								System.out.println("Problema para exibir registros!");
							}
						} else {
							System.out.println("A pesquisa não retornou nenhum registro!");
						}
					break;
					case 3:
						System.out.println("NOME DO ALBUM:");
						nome = x.nextLine();
						
						ResultSet res2 = (ResultSet) Conexao.pesqAlbum(nome);
						if(res2!=null) {
							try {
								while(res2.next()) {
									System.out.println("ID: "+res2.getInt("id"));
									System.out.println("Nome: "+res2.getString("nome"));
									System.out.println("Ano: "+res2.getInt("ano"));
									System.out.println("==========");
								}
							} catch (SQLException e) {
								System.out.println("Problema para exibir registros!");
							}
						} else {
							System.out.println("A pesquisa não retornou nenhum registro!");
						}
					break;	
					case 4:
						System.out.println("SAINDO!!!");
					break;
					default:
						System.out.println("OPCAO INVALIDA!!!");
					}
			break;
			case 3:
				ResultSet res3 = (ResultSet) Conexao.relatorioCompleto();
				if(res3!=null) {
					try {
						while(res3.next()) {
							System.out.println("Musica: "+res3.getString("musica.nome"));
							System.out.println("Artista: "+res3.getString("artista.nome"));
							System.out.println("Album: "+res3.getString("album.nome"));
							System.out.println("Genero: "+res3.getString("genero.tipo"));
							System.out.println("Nota: "+res3.getInt("musica.nota"));
							System.out.println("==========");
						}
					} catch (SQLException e) {
						System.out.println("Problema para exibir registros!");
					}
				} else {
					System.out.println("A pesquisa não retornou nenhum registro!");
				}
			break;
			case 4:
				System.out.println("SAINDO!!!");
			break;
			default:
				System.out.println("OPCAO INVALIDA!!!");
		}
		}while(opc != 4);
}
}
