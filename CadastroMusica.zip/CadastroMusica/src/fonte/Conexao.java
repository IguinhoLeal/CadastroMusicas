/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fonte;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author Igor
 */
public class Conexao {
    //Método para Conectar ao Banco de Dados Local chamado 'cadastro', usuário 'root' e senha em branco!
	public static Connection conectar() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection c = DriverManager.getConnection("jdbc:mysql://localhost/cadastromusicas", "root", "leal123");
			return(c);
		} catch (ClassNotFoundException e) {
			System.out.println("Problema na configuração do Driver do MySQL!");
		} catch (SQLException e) {
			System.out.println("Problema na conexão com o banco de dados!");
		}
		return(null);
	}
	
	//Retorna o relatório contendo todas as Pessoa do Banco
	public static ResultSet relatorio() {
		Connection con = conectar();
		Statement st;
		try {
			st = con.createStatement();
			return(st.executeQuery("SELECT * FROM musica;"));
		} catch (SQLException e) {
			System.out.println("Problema na consulta à tabela musica!");
		}
		return(null);
	}
	
	//PESQUISA NOME DA MUSICA
		public static ResultSet pesqMusica(String nome) {
			Connection con = conectar();
			Statement st;
			try {
				st = con.createStatement();
				return(st.executeQuery("SELECT nome,duracao,nota FROM musica where nome = '"+nome+"';"));
			} catch (SQLException e) {
				System.out.println("Problema na consulta à tabela Musica!");
			}
			return(null);
		}
		//PESQUISA NOME ARTISTA
				public static ResultSet pesqArtista(String nome) {
					Connection con = conectar();
					Statement st;
					try {
						st = con.createStatement();
						return(st.executeQuery("SELECT id,nome FROM artista where nome = '"+nome+"';"));
					} catch (SQLException e) {
						System.out.println("Problema na consulta à tabela Artista !");
					}
					return(null);
				}
				//PESQUISA NOME ALBUM
				public static ResultSet pesqAlbum(String nome) {
					Connection con = conectar();
					Statement st;
					try {
						st = con.createStatement();
						return(st.executeQuery("SELECT id,nome,ano FROM album where nome = '"+nome+"';"));
					} catch (SQLException e) {
						System.out.println("Problema na consulta à tabela Album!");
					}
					return(null);
				}
	//Método para inserir no banco uma Pessoa passada como parâmetro
	public static int inserirMusica(Musica m,int fk) {
		String insercao = "INSERT INTO `musica` (`Nome`, `Duracao`, `Nota`,`FK_Album`) VALUES ('"+m.getNome()+"',"+m.getDuracao()+",'"+m.getNota()+"','"+fk+"');";
		Connection con = conectar();
		Statement st;
		try {
			st = con.createStatement();
			return(st.executeUpdate(insercao));
		} catch (SQLException e) {
			System.out.println("Problema na inserção da Musica!");
		}
		return(0);
	}
	
	public static int inserirAlbum(Album a,int fk) {
		String insercao = "INSERT INTO `album` (`Nome`, `Ano`,`FK_Artista`) VALUES ('"+a.getNome()+"',"+a.getAno()+",'"+fk+"');";
		Connection con = conectar();
		Statement st;
		try {
			st = con.createStatement();
			return(st.executeUpdate(insercao));
		} catch (SQLException e) {
			System.out.println("Problema na inserção do Album!");
		}
		return(0);
	}
	
	
	//Método para remover do banco uma Pessoa pelo 'telefone'
	public static int removerPeloTelefone(String nome) {
		String remocao = "DELETE FROM `musica` WHERE `nome` = '"+nome+"'";
		Connection con = conectar();
		Statement st;
		try {
			st = con.createStatement();
			return(st.executeUpdate(remocao));
		} catch (SQLException e) {
			System.out.println("Problema na remoção da musica!");
		}
		return(0);
	}
	
	
	//Método para Atualizar os campos no banco uma Pessoa passada como parâmetro, buscando-a pelo nome atual!!!
	public static int atualizar(Musica m, String n) {
		String atualizacao = "UPDATE `musica` SET `nome` = '"+m.getNome()+"', `duracao` = "+m.getDuracao()+", `nota` = '"+m.getNota()+"' WHERE `nome` = '"+n+"';";
		Connection con = conectar();
		Statement st;
		try {
			st = con.createStatement();
			return(st.executeUpdate(atualizacao));
		} catch (SQLException e) {
			System.out.println("Problema na atualização da Musica!");
		}
		return(0);
	}
	
	//INSERIR GENERO//
	public static int inserirGenero(Genero m) {
		String insercao = "INSERT INTO `genero` (`Tipo`) VALUES ('"+m.getTipo()+"');";
		Connection con = conectar();
		Statement st;
		try {
			st = con.createStatement();
			return(st.executeUpdate(insercao));
		} catch (SQLException e) {
			System.out.println("Problema na inserção do Genero!");
		}
		return(0);
	}
	
	//INSERIR ARTISTA//
	public static int inserirArtista(Artista a, int fk) {
		String insercao = "INSERT INTO `artista` (`nome`,`FK_Genero`) VALUES ('"+a.getNome()+"','"+fk+"');";
		Connection con = conectar();
		Statement st;
		try {
			st = con.createStatement();
			return(st.executeUpdate(insercao));
		} catch (SQLException e) {
			System.out.println("Problema na inserção do Artista!");
		}
		return(0);
	}
	//LISTAR ALBUNS//
	public static ResultSet relatorioAlbum() {
		Connection con = conectar();
		Statement st;
		try {
			st = con.createStatement();
			return(st.executeQuery("SELECT * FROM album;"));
		} catch (SQLException e) {
			System.out.println("Problema na consulta à tabela Album!");
		}
		return(null);
	}
	//LISTAR ARTISTAS//
		public static ResultSet relatorioArtista() {
			Connection con = conectar();
			Statement st;
			try {
				st = con.createStatement();
				return(st.executeQuery("SELECT * FROM artista;"));
			} catch (SQLException e) {
				System.out.println("Problema na consulta à tabela Artista!");
			}
			return(null);
		}
		//LISTAR GENEROS//
		public static ResultSet relatorioGenero() {
			Connection con = conectar();
			Statement st;
			try {
				st = con.createStatement();
				return(st.executeQuery("SELECT * FROM genero;"));
			} catch (SQLException e) {
				System.out.println("Problema na consulta à tabela Generos!");
			}
			return(null);
		}
		//relatorio completo
		public static ResultSet relatorioCompleto() {
			Connection con = conectar();
			Statement st;
			try {
				st = con.createStatement();
				return(st.executeQuery("select musica.nome,artista.nome,album.nome,genero.tipo,musica.nota from musica, artista,album,genero where(musica.fk_album = album.id and album.fk_artista = artista.id and artista.fk_genero = genero.id);"));
			} catch (SQLException e) {
				System.out.println("Problema na consulta às tabelas!");
			}
			return(null);
		}
}
